//  Deductions.swift

import PlaygroundSupport




// Uncapped Deduction checks




// Capped Deduction checks




// Uncapped Deductions
public func ppfInterestDed() -> Int {
    show("Interest received from PPF this year:")
    let ppfInterest = askForNumber("0")
    return ppfInterest
}

public func taxSavingMutualFundInterestDed() -> Int {
    show("Interest from tax saving mutual funds:")
    let taxSavingMutualFundInterest = askForNumber("0")
    return taxSavingMutualFundInterest
}

public func educationLoanInterestDed() -> Int {
    show("Interest paid on education loan sanction within last 8 years for self or family member:")
    let educationLoanInterest = askForNumber("0")
    return educationLoanInterest
}

public func npsEmployerDed() -> Int {
    show("Employer's contribution towards National Pension Scheme (maximum upto 10% of salary):")
    let npsEmployer = askForNumber("0")
    return npsEmployer
} // Do employeeCheck()



// Capped Deductions - Section 80C
public func ppfAndTaxSavingFDDed() -> Int {
    show("Amount invested in PPF and tax saving FDs this year:")
    let ppfAndTaxSavingFD = askForNumber("0")
    return ppfAndTaxSavingFD
}

public func epfDed() -> Int {
    show("Contribution to Employee Provident Fund (EPF):")
    let epf = askForNumber("0")
    return epf
} // Do employeeCheck()

public func taxSavingMutualFundDed() -> Int {
    show("Investment in tax saving mutual funds:")
    let taxSavingMutualFund = askForNumber("0")
    return taxSavingMutualFund
}

public func lifeInsurancePremiumDed() -> Int {
    show("Life Insurance premium paid:")
    let lifeInsurancePremium = askForNumber("0")
    return lifeInsurancePremium
}

public func principleRepaymentOfHomeLoanDed() -> Int {
    show("Home loan principle repayment made:")
    let principleRepaymentOfHomeLoan = askForNumber("0")
    return principleRepaymentOfHomeLoan
}

public func childTuitionDed() -> Int {
    show("Children's tuition fees paid this year:")
    let childTuition = askForNumber("0")
    return childTuition
} // Do childCheck()

public func seniorCitizensSavingSchemeDed() -> Int {
    show("Investment in Senior Citizen's Saving Scheme:")
    let seniorCitizensSavingScheme = askForNumber("0")
    return seniorCitizensSavingScheme
} // age > 50


// Capped Deductions - 80CCC
public func annuityPlanDed() -> Int {
    show("Contribution made towards Annuity Plans for receiving pension from the fund:")
    let annuityPlan = askForNumber("0")
    return annuityPlan
} // Under same cap as Section 80C


// Capped Deductions - 80CCD(1) & 80CCD(1B)
public func npsDed() -> Int {
    show("Your contribution towards National Pension Scheme:")
    let nps = askForNumber("0")
    return nps
} // First remove ₹50,000 as additional deduction permitted under 80CCD(1B) and compute rest under common cap as 80C and 80CCC


// Capped Deductions - 80TTA(1) & 80TTB
public func savingsAccountDed() -> Int {
    show("Interest from savings accounts:")
    let savingsAccount = askForNumber("0")
    return savingsAccount
} // Capped at Rs. 10,000 for age<60 & ₹50,000 for age>60


// Capped Deductions - 80GG
public func rentDed() -> Int {
    show("Total annual rent paid (only if you do not receive HRA from employer):")
    let rent = askForNumber("0")
    return rent
} // Do employeeCheck(), Capped at ₹5000*12 i.e. ₹60,0000


// Capped Deductions - 80EE
public func homeLoanInterestDed() -> Int {
    show("Interest paid on home loan (of less than ₹350,000) for first time home-owners:")
    let homeLoanInterest = askForNumber("0")
    return homeLoanInterest
} // Capped at ₹50,000


// Capped Deductions - 80CCG
public func equityDed() -> Int {
    show("Rajiv Gandhi Equity Scheme - Amount invested in equities:")
    let equity = askForNumber("0")
    return equity
} // Capped at lower of 50% of amount invested or ₹25,000


// Capped Deductions - 80D
public func medicalInsuranceDed() -> Int {
    show("Medical insurance for self, spouse or children:")
    let medicalInsurance = askForNumber("0")
    return medicalInsurance
} // for age<60, Capped at ₹25,000

public func parentMedicalInsuranceDed() -> Int {
    show("Medical insurance for parents older than 60 years:")
    let parentMedicalInsurance = askForNumber("0")
    return parentMedicalInsurance
} // for age<60, Capped at ₹50,000

public func seniorMedicalInsuranceDed() -> Int {
    show("Medical insurance for self or spouse:")
    let seniorMedicalInsurance = askForNumber("0")
    return seniorMedicalInsurance
} // for age>60, Capped at ₹50,000


// Capped Deductions - 80DDB
public func medicalExpensesDed() -> Int {
    show("Medical expenses on self or dependent relative:")
    let medicalExpenses = askForNumber("0")
    return medicalExpenses
} // Capped at ₹40,000 for age<60 & ₹100,000 for age>60
