//#-code-completion(module, hide, Swift)
//#-code-completion(identifier, hide, _setup())
//#-code-completion(identifier, hide, AbstractPointChartable)
//#-hidden-code
import Foundation
_setupCharts()


var monthlyInstallment = 0
var years = 0

//#-end-hidden-code
/*:
 **Introduction**: This is an approximate comparison to show how the amount invested regularly in [Equity Mutual Fund](glossary://Equity%20Mutual%20Fund), also known as [SIP](glossary://SIP), compares to that routinely invested in [Debt Mutual Fund](glossary://Debt%20Mutual%20Fund) at monthly intervals. We also provide a graph showing how your returns would increase as you shift your investment from Debt to Equity Mutual fund.

  **Guide:** Enter the amount of money that you are willing to invest per month and the number of years for which you want to make these investments. Then run the code
*/
//#-editable-code
monthlyInstallment = 100
years = 5
//#-end-editable-code
/*:
 The graph plotted has the Maturity Value on the y-axis and the x-axis starts with 100% debt investment and ends with 100% equity investment. The line also shows the intermediary values showing an increasing shift from debt to equity. A rate of 8% p.a. return on debt mutual fund and 15% p.a. on equity mutual fund is assumed on the safer side. The compounding has been done on an annual basis.
 
 **About**: In many ways, equity funds are ideal [Investment vehicles](glossary://Investment%20vehicle) for investors that are not as well-versed in financial investing or do not possess a significant amount of capital with which to invest. Equity funds are sound investments for most people.
 The attributes that make equity funds most suitable for small individual investors are the reduction of risk resulting from a fund's portfolio [diversification](glossary://Diversification) and the relatively small amount of capital required to acquire shares of an equity fund. A significant amount of investment capital would be necessary for an individual investor to achieve a similar degree of risk reduction through diversification of a portfolio of direct stock holdings. Pooling small investors' capital allows an equity fund to diversify efficiently without burdening each investor with large capital requirements.
 The price of the equity fund is based on the fund's [Net asset value (NAV)](glossary://Net%20asset%20value) less its liabilities. A more [diversified fund](glossary://Diversified%20Fund) means that there is a less negative effect of an individual stock's adverse price movement on the overall portfolio and the share price of the equity fund.
 Experienced professional [Portfolio Manager](glossary://Portfolio%20Manager) manages equity funds, and their past performance is a matter of public record. The federal government heavily regulates transparency and reporting requirements for equity funds.
 */
//#-hidden-code

var monthlyInstallmentDouble = Double(monthlyInstallment)
var yearsDouble = Double(years)

var maturityValue = XYData()

let debtRateOfInterest = 0.08
let equityRateOfInterest = 0.15

func maturityValueCalculator(rateOfInterest: Double, years: Double, monthlyInstallment: Double) -> Double {
    let numerator = pow((1.0+rateOfInterest), years) - 1.0
    let denominator = 1.0 - pow((1.0 + rateOfInterest), -(1.0/12.0))
    let maturityValue = monthlyInstallment*numerator/denominator
    return maturityValue
}

for i in 0...10 {
    let iDouble = Double(i)
    let debtMonthlyInstallment = monthlyInstallmentDouble*(1.0 - (iDouble/10.0))
    let equityMonthlyInstallment = monthlyInstallmentDouble - debtMonthlyInstallment
    let debtMaturityValue = maturityValueCalculator(rateOfInterest: debtRateOfInterest, years: yearsDouble, monthlyInstallment: debtMonthlyInstallment)
    let equityMaturityValue = maturityValueCalculator(rateOfInterest: equityRateOfInterest, years: yearsDouble, monthlyInstallment: equityMonthlyInstallment)
    let sum = debtMaturityValue + equityMaturityValue
    maturityValue.append(x: iDouble*10.0, y: sum)
}

let line = LinePlot(xyData: maturityValue)
line.color = .red
line.label = "Maturity value"


//#-end-hidden-code

