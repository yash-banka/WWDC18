import UIKit
import PlaygroundSupport

public func _setup() {
    let viewController = UIViewController()
    viewController.view = Canvas.shared.backingView
    PlaygroundPage.current.liveView = viewController
}


// Charts

class ChartViewController: UIViewController, PlaygroundLiveViewSafeAreaContainer {
    
    override func loadView() {
        self.view = Chart.shared.chartView
    }
    
    override func viewDidLoad() {
        if let chartView = view as? ChartView {
            chartView.chartSafeAreaLayoutGuide = liveViewSafeAreaGuide
        }
    }
    
}

public func _setupCharts() {
    PlaygroundPage.current.liveView = ChartViewController()
}
