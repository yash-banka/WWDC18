//#-code-completion(identifier, hide, setupLiveView())
//#-hidden-code
import Foundation
import PlaygroundSupport
import Darwin

/*
 The code is modular. All deductions are in the form of functions in a separate source file and changes based on change in laws can be easily made. Similarly, the deduction caps and tax rates are stored in constants and are easy to identify in the TaxCalculation source file.
 */

//#-end-hidden-code
/*:
 **Guide:** Answer each question with correct data. Put a zero if you haven't invested in the mentioned scheme or if it is not applicable to you.
 
 **Working:** First, the essential details such as age, [gross income](glossary://gross%20income), employment status, and parenthood are considered. Based on this relevant questions are asked to collect information of probable [deduction](glossary://deduction) sources. These are then totaled up under the relevant sections of the Tax Code and checked against the caps. If it exceeds the cap, then the excess amount is disregarded. Tax rates, deductions, and caps, all vary based on age and employment status. The total of the deductions is then subtracted from the gross income to get the [taxable income](glossary://taxable%20income) based on which the correct [tax bracket](glossary://tax%20bracket) is identified. Required [surcharges](glossary://surcharge) and [cesses](glossary://cess) are computed, and the total tax liability is then presented.
 
 **Hint:** If you wish to test this Playground but are confused as to the values to put, here is a range of values that would be appropriate
 
 ``Gross Income``: 5,000,000 to 7,500,000
 
 All other numeric fields: 500 to 10,000
 */
//#-hidden-code



// Name
show("Hi, what is your name?")
let name = ask("John Appleseed")

// Age
show("How old are you?")
let age = askForNumber("45")

// Negative Age check
if age < 0 {
    show("Age cannot be negative!")
    over()
}

// Check eligibility to file returns
if age < 18 {
    show("\(name), you need to turn 18 before you can file tax returns!")
    over()
}

// Gross annual income
show("What is you gross annual income in INR (₹)?")
let grossIncome = askForNumber("1050000")
if grossIncome <= 0 {
    show("You don't need to pay taxes!")
    over()
}

if age <= 60 {
    if grossIncome <= 250_000 {
        exemptedFromTax()
    }
} else if age <= 80 {
    if grossIncome <= 300_000 {
        exemptedFromTax()
    }
} else {
    if grossIncome <= 500_000 {
        exemptedFromTax()
    }
}



// Employee check
var employee = false
if age < 60 {
    employee = employeeCheck()
}

// Children check
var children = false
if age < 60 {
    children = childCheck()
}



// Deductions
var ppfAndTaxSavingFD = ppfAndTaxSavingFDDed()
var ppfInterest = ppfInterestDed()

var taxSavingMutualFund = taxSavingMutualFundDed()
var taxSavingMutualFundInterest = taxSavingMutualFundInterestDed()

var lifeInsurancePremium = lifeInsurancePremiumDed()

var principleRepaymentOfHomeLoan = 0
if age < 80 {
    principleRepaymentOfHomeLoan = principleRepaymentOfHomeLoanDed()
}

var childTuition = 0
var educationLoanInterest = 0
if children == true {
    childTuition = childTuitionDed()
    educationLoanInterest = educationLoanInterestDed()
}

var seniorCitizensSavingScheme = 0
if age > 50 {
    seniorCitizensSavingScheme = seniorCitizensSavingSchemeDed()
}

var annuityPlan = 0
var nps = 0
var npsEmployer = 0
var epf = 0
var rent = 0
if age < 80 {
    annuityPlan = annuityPlanDed()
    nps = npsDed()
}
if employee == true {
    npsEmployer = npsEmployerDed()
    epf = epfDed()
    rent = rentDed()
}

var savingsAccount = savingsAccountDed()

var homeLoanInterest = homeLoanInterestDed()

var equity = equityDed()

var medicalInsurance = 0
var parentMedicalInsurance = 0
var seniorMedicalInsurance = 0
if age < 60 {
    medicalInsurance = medicalInsuranceDed()
    parentMedicalInsurance = parentMedicalInsuranceDed()
} else {
    seniorMedicalInsurance = seniorMedicalInsuranceDed()
}

var medicalExpenses = medicalExpensesDed()




// Deduction Caps
let sec80Cap = 1_50_000
let sec80CCDAddCap = 50_000
let sec80TTCap = 10_000
let sec80TTSrCap = 50_000
let sec80GGCap = 60_000
let sec80EECap = 50_000
let sec80CCGCap = 25_000
let sec80DCap = 25_000
let sec80DParentCap = 50_000
let sec80DSrCap = 50_000
let sec80DDBCap = 40_000
let sec80DDBSrCap = 100_000

// Deductions
var sec80 = 0
var sec80CCDAdd = 0
var sec80TT = 0
var sec80GG = 0
var sec80EE = 0
var sec80CCG = 0
var sec80D = 0
var sec80DDB = 0

// Deduction Cap Check
var sec80C = ppfAndTaxSavingFD + epf + taxSavingMutualFund + lifeInsurancePremium + principleRepaymentOfHomeLoan + childTuition + seniorCitizensSavingScheme
var sec80CCC = annuityPlan
var sec80CCD = nps


if sec80CCD > sec80CCDAddCap {
    sec80CCDAdd = sec80CCDAddCap
    sec80CCD -= sec80CCDAddCap
    sec80 = sec80C + sec80CCC + sec80CCD
} else {
    sec80CCDAdd = sec80CCD
    sec80 = sec80C + sec80CCC
}
if sec80 > sec80Cap {
    sec80 = sec80Cap
}

sec80TT = savingsAccount
if age < 60 {
    if sec80TT > sec80TTCap {
        sec80TT = sec80TTCap
    }
} else {
    if sec80TT > sec80TTSrCap {
        sec80TT = sec80TTSrCap
    }
}

sec80GG = rent
if sec80GG > sec80GGCap {
    sec80GG = sec80GGCap
}

sec80EE = homeLoanInterest
if sec80EE > sec80EECap {
    sec80EE = sec80EECap
}

sec80CCG = equity
if (sec80CCG/2) < sec80CCGCap {
    sec80CCG /= 2
} else {
    sec80CCG = sec80CCGCap
}


if medicalInsurance > sec80DCap {
    medicalInsurance = sec80DCap
}
if parentMedicalInsurance > sec80DParentCap {
    parentMedicalInsurance = sec80DParentCap
}
if seniorMedicalInsurance > sec80DSrCap {
    seniorMedicalInsurance = sec80DSrCap
}
sec80D = medicalInsurance + parentMedicalInsurance + seniorMedicalInsurance

sec80DDB = medicalExpenses
if age < 60 {
    if sec80DDB > sec80DDBCap {
        sec80DDB = sec80DDBCap
    }
} else {
    if sec80DDB > sec80DDBSrCap {
        sec80DDB = sec80DDBSrCap
    }
}




// Final Deductions

var deduction = sec80 + sec80CCDAdd + sec80TT + sec80GG + sec80EE + sec80CCG + sec80D + sec80DDB + ppfInterest + taxSavingMutualFundInterest + educationLoanInterest + npsEmployer


if deduction >= grossIncome {
    exemptedFromTax()
}


// Net Income
let netIncomeInt = grossIncome - deduction
let netIncome = Double(netIncomeInt)

// Tax
var tax = taxCalculator(age: age, netIncome: netIncome)

// Surcharges, Cesses & Rebates
var surcharge = surchargeCalculator(netIncome: netIncome, tax: tax, age: age)
var taxWithSurcharge = tax + surcharge
let healthAndEducationCess = 0.03
var cess = taxWithSurcharge * healthAndEducationCess
var taxWithSurchargeAndCess = taxWithSurcharge + cess
var rebate = 0.0 // Section 87A
let rebateCap = 5_000.0
if netIncome <= 500_000.0 {
    if rebateCap < taxWithSurchargeAndCess {
        rebate = rebateCap
    } else {
        rebate = taxWithSurchargeAndCess
    }
}

var finalTax = taxWithSurchargeAndCess - rebate
var finalTaxInt = Int(finalTax)
var surchargeString = ""
var rebateString = ""


if finalTaxInt == 0 {
    show("\(name), you do not have any tax liabilty!")
} else {
    if surcharge > 0 {
        surchargeString = "\nSurcharge: ₹\(Int(surcharge).formattedWithSeparator)"
    }
    if rebate > 0 {
        rebateString = "\nRebate (under Section 87A): - ₹\(Int(rebate).formattedWithSeparator)"
    }
    
    show("You entered your gross income as ₹\(grossIncome.formattedWithSeparator) and are eligible for ₹\(deduction.formattedWithSeparator) as deductions.\nTherefore, your taxable income is ₹\(netIncomeInt.formattedWithSeparator).")
    show("\(name), your tax liabilty is ₹\(finalTaxInt.formattedWithSeparator).")
    show("The breakup is as follows:\nBasic Tax: ₹\(Int(tax).formattedWithSeparator)\(surchargeString)\nHealth & Education Cess: ₹\(Int(cess).formattedWithSeparator)\(rebateString)")
    if sec80 < sec80Cap {
        show("You are not making full use of the Section 80C deduction, consider appropriate investments to reduce your tax liability.")
    }
}
//#-end-hidden-code
