//  EligibilityChecks.swift

import PlaygroundSupport

public func employeeCheck() -> Bool {
    var employee = false
    show("Are you a salaried employee?")
    let employeeString = askForChoice("Yes or No", options: ["Yes", "No"])
    if employeeString == "Yes" {
        employee = true
    }
    return employee
}

public func childCheck() -> Bool {
    var children = false
    show("Do you have children?")
    let childrenString = askForChoice("Yes or No", options: ["Yes", "No"])
    if childrenString == "Yes" {
        children = true
    }
    return children
}
