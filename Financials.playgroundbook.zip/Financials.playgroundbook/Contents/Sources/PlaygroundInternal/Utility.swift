//  Utility.swift

import PlaygroundSupport
import Darwin
import Foundation


// For converting Integers to Strings with commas
extension Formatter {
    static let withSeparator: NumberFormatter = {
        let formatter = NumberFormatter()
        formatter.groupingSeparator = ","
        formatter.numberStyle = .decimal
        return formatter
    }()
}

extension BinaryInteger{
    public var formattedWithSeparator: String {
        return Formatter.withSeparator.string(for: self) ?? ""
    }
}





// Stopping Playground execution prematurely
public func over(){
    sleep(2)
    show("Ending program...")
    sleep(3)
    exit(0)
}
