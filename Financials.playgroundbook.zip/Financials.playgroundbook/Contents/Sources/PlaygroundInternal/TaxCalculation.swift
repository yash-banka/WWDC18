//  Functions.swift

import PlaygroundSupport




// Exempted from tax

public func exemptedFromTax() {
    show("You do not have any income tax liability!")
    over()
}


// Tax Rates
public let taxRate5 = 0.05
public let taxRate20 = 0.2
public let taxRate30 = 0.3
public let surcharge10 = 0.1
public let surcharge15 = 0.15

// Surcharge Caps
public let cap1Cr = 10_000_000.0
public let cap50L = 5_000_000.0



// Tax calculation on net income
public func taxCalculator(age: Int, netIncome: Double) -> Double {
    var tax = 0.0
    switch age {
    case 0...60:
        switch netIncome {
        case 0...250_000:
            exemptedFromTax()
        case 250_001...500_000:
            tax = (netIncome-250_000)*taxRate5
        case 5_00_001...10_00_000:
            tax = (2_50_000*taxRate5)+((netIncome-500_000)*taxRate20)
        default:
            tax = (250_000*taxRate5)+(500_000*taxRate20)+((netIncome-1_000_000)*taxRate30)
        }
    case 61...80:
        switch netIncome {
        case 0...300_000:
            exemptedFromTax()
        case 300_001...500_000:
            tax = (netIncome-3_00_000)*taxRate5
        case 500_001...1_000_000:
            tax = (200_000*taxRate5)+((netIncome-500_000)*taxRate20)
        default:
            tax = (200_000*taxRate5)+(500_000*taxRate20)+((netIncome-1_000_000)*taxRate30)
        }
    default:
        switch netIncome {
        case 0...500_000:
            exemptedFromTax()
        case 500_001...1_000_000:
            tax = (netIncome-500_000)*taxRate20
        default:
            tax = (500_000*taxRate20)+((netIncome-1_000_000)*taxRate30)
        }
    }
    return tax
}



// Surcharge calculation:

public func surchargeCalculator(netIncome: Double, tax: Double, age: Int) -> Double {
    var surcharge = 0.0
    var surcharge1Cr = 0.0
    var surcharge50L = 0.0
    var taxWithSurcharge = 0.0
    var incrementalSalary = 0.0
    var incrementalTaxWithSurcharge = 0.0
    var incrementalTaxWithoutSurcharge = 0.0
    var taxOnCap = 0.0
    if netIncome > cap1Cr {
        surcharge1Cr = tax * surcharge15
        taxWithSurcharge = tax + surcharge1Cr
        taxOnCap = taxCalculator(age: age, netIncome: cap1Cr)
        incrementalSalary = netIncome - cap1Cr
        incrementalTaxWithSurcharge = taxWithSurcharge - taxOnCap
        if incrementalTaxWithSurcharge > incrementalSalary {
            incrementalTaxWithoutSurcharge = tax - taxOnCap
            surcharge1Cr = incrementalSalary - incrementalTaxWithoutSurcharge
        }
    }
    if netIncome > cap50L {
        surcharge50L = tax * surcharge10
        taxWithSurcharge = tax + surcharge50L
        taxOnCap = taxCalculator(age: age, netIncome: cap50L)
        incrementalSalary = netIncome - cap50L
        incrementalTaxWithSurcharge = taxWithSurcharge - taxOnCap
        if incrementalTaxWithSurcharge > incrementalSalary {
            incrementalTaxWithoutSurcharge = tax - taxOnCap
            surcharge50L = incrementalSalary - incrementalTaxWithoutSurcharge
        }
    }
    if netIncome > cap1Cr {
        if surcharge50L > surcharge1Cr {
            surcharge  = surcharge50L
        } else {
            surcharge = surcharge1Cr
        }
    } else {
        surcharge = surcharge50L
    }
    return surcharge
}














