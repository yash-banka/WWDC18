//#-code-completion(module, hide, Swift)
//#-code-completion(identifier, hide, _setup())
//#-code-completion(identifier, hide, AbstractDrawable)
//#-code-completion(identifier, hide, _ColorLiteralType)
//#-hidden-code
_setup()
import UIKit
import AVFoundation

let fontURL = Bundle.main.url(forResource: "ChicagoFLF", withExtension: "ttf")
CTFontManagerRegisterFontsForURL(fontURL! as CFURL, CTFontManagerScope.process, nil)
let ChicagoFLF = UIFont(name: "ChicagoFLF", size: 12)

// Colors
let beige1 = Color(red: 1.0000, green: 0.9804, blue: 0.9020, alpha: 1.0)
let beige2 = Color(red: 0.9922, green: 0.9608, blue: 0.9020, alpha: 1.0)
let beige3 = Color(red: 0.9333, green: 0.8745, blue: 0.8000, alpha: 1.0)
let beige4 = Color(red: 0.8039, green: 0.5137, blue: 0.4706, alpha: 0.375)
let black1 = Color(red: 0.0000, green: 0.0000, blue: 0.0000, alpha: 1.0)
let black2 = Color(red: 0.0000, green: 0.0000, blue: 0.0000, alpha: 0.5)
let grey1 = Color(red: 0.8275, green: 0.8275, blue: 0.8275, alpha: 1.0)
let grey2 = Color(white: 0.2, alpha: 1.0)
let white1 = Color(red: 1.0000, green: 1.0000, blue: 1.0000, alpha: 1.0)
let green1 = Color(red: 0.0000, green: 1.0000, blue: 0.0000, alpha: 1.0)
let yellow1 = Color(red: 1.0000, green: 1.0000, blue: 0.0000, alpha: 1.0)
let yellow2 = Color(red: 1.0000, green: 1.0000, blue: 0.0000, alpha: 1.0)
let red1 = Color(red: 1.0000, green: 0.0000, blue: 0.0000, alpha: 1.0)
let blue1 = Color(red: 0.0000, green: 0.0000, blue: 1.0000, alpha: 1.0)
let blue2 = Color(red: 0.5294, green: 0.8078, blue: 0.9804, alpha: 1.0)

// Connecting cord
let connectingCord = Rectangle(width: 15.0, height: 0.250, cornerRadius: 0.0)
connectingCord.color = grey1
connectingCord.center.y = -9.75
connectingCord.center.x = 0.0

// Mac
let macBase = Rectangle(width: 14.0, height: 4.0, cornerRadius: 0.0)
macBase.color = beige2
macBase.center.y = -8.375
macBase.center.x = 13.0

let macBody = Rectangle(width: 15.0, height: 17.0, cornerRadius: 1.25)
macBody.color = beige1
macBody.center.y = 0.0
macBody.center.x = 13.0

let macScreen = Rectangle(width: 12.0, height: 10.0, cornerRadius: 1.25)
macScreen.color = black1
macScreen.borderColor = beige3
macScreen.borderWidth = 2.0
macScreen.center.y = 2.0
macScreen.center.x = 13.0

let macGroove = Rectangle(width: 15.0, height: 0.75, cornerRadius: 0.0)
macGroove.color = beige2
macGroove.center.y = -5.5
macGroove.center.x = 13.0

let macDiskSlot = Rectangle(width: 4.175, height: 0.75, cornerRadius: 0.15)
macDiskSlot.color = black1
macDiskSlot.center.y = -5.5
macDiskSlot.center.x = 16.0

let macDiskHole = Circle(radius: 0.075)
macDiskHole.color = black1
macDiskHole.center.y = -5.5
macDiskHole.center.x = 18.75

let macDisplay1 = Rectangle(width: 10.5, height: 8.5, cornerRadius: 0.0)
macDisplay1.color = black1
macDisplay1.center.y = 2.0
macDisplay1.center.x = 13.0

let hello = Image(name: "hello")
hello.size.width *= 0.5
hello.size.height *= 0.5
hello.center.y = 2.0
hello.center.x = 13.0
hello.tint = .clear

let printButtonBorder = Rectangle(width: 9.4, height: 3.4, cornerRadius: 0.65)
printButtonBorder.color = .clear
printButtonBorder.center.y = 0.0
printButtonBorder.center.x = 13.0

let printButton = Rectangle(width: 9.0, height: 3.0, cornerRadius: 0.5)
printButton.color = Color(white: 0.0, alpha: 0.0)
printButton.center.y = 0.0
printButton.center.x = 13.0

let printButtonText = Text(string: "", fontSize: 12.0, fontName: "ChicagoFLF", color: black1)
printButtonText.center.y = 0.0
printButtonText.center.x = 13.0

let screenText = Text(string: "", fontSize: 12.0, fontName: "ChicagoFLF", color: black1)
printButtonText.center.y = 3.75
printButtonText.center.x = 13.0

let tapPrompt = Text(string: "", fontSize: 12.0, fontName: "ChicagoFLF", color: grey1)
tapPrompt.center.y = 3.75
tapPrompt.center.x = 24.0

let arrow = Image(name: "Arrow")
arrow.size.width *= 0.25
arrow.size.height *= 0.25
arrow.center.y = 0.0
arrow.center.x = 24.0
arrow.tint = .clear

let macOverlay = Rectangle(width: 15.0, height: 17.0, cornerRadius: 1.25)
macOverlay.color = .clear
macOverlay.center.y = 0.0
macOverlay.center.x = 13.0

// Dot-Matrix Printer
let printerBack = Rectangle(width: 19.5, height: 3.5, cornerRadius: 0.2)
printerBack.color = beige3
printerBack.center.x = -11.25
printerBack.center.y = -7.125

let printerCoverBack = Rectangle(width: 12.5, height: 0.75, cornerRadius: 0.0)
printerCoverBack.color = black2
printerCoverBack.center.x = -12.0
printerCoverBack.center.y = -5.75

let paper = Rectangle(width: 10.0, height: 14.0)
paper.color = white1
paper.center.y = -13.0
paper.center.x = -12.0

let printedText1 = Text(string: "", fontSize: 8.0, fontName: "ChicagoFLF", color: black1)
printedText1.center.y = -6.75
printedText1.center.x = -12.0

let printedText2 = Text(string: "", fontSize: 8.0, fontName: "ChicagoFLF", color: black1)
printedText2.center.y = -7.25
printedText2.center.x = -12.0

let printedText3 = Text(string: "", fontSize: 8.0, fontName: "ChicagoFLF", color: black1)
printedText3.center.y = -7.75
printedText3.center.x = -12.0

let printedText4 = Text(string: "", fontSize: 8.0, fontName: "ChicagoFLF", color: black1)
printedText4.center.y = -8.25
printedText4.center.x = -12.0

let printedText5 = Text(string: "", fontSize: 8.0, fontName: "ChicagoFLF", color: black1)
printedText5.center.y = -8.75
printedText5.center.x = -12.0

let printedText6 = Text(string: "", fontSize: 8.0, fontName: "ChicagoFLF", color: black1)
printedText6.center.y = -9.25
printedText6.center.x = -12.0

let printedText7 = Text(string: "", fontSize: 8.0, fontName: "ChicagoFLF", color: black1)
printedText7.center.y = -9.75
printedText7.center.x = -12.0

let printedText8 = Text(string: "", fontSize: 8.0, fontName: "ChicagoFLF", color: black1)
printedText8.center.y = -10.25
printedText8.center.x = -12.0

let printedText9 = Text(string: "", fontSize: 8.0, fontName: "ChicagoFLF", color: black1)
printedText9.center.y = -10.75
printedText9.center.x = -12.0

let printedText10 = Text(string: "", fontSize: 8.0, fontName: "ChicagoFLF", color: black1)
printedText10.center.y = -11.25
printedText10.center.x = -12.0

let printedText11 = Text(string: "", fontSize: 8.0, fontName: "ChicagoFLF", color: black1)
printedText11.center.y = -11.75
printedText11.center.x = -12.0

let printedText12 = Text(string: "", fontSize: 10.0, fontName: "ChicagoFLF", color: black1)
printedText12.center.y = -19.0
printedText12.center.x = -12.0

let pageOverlay1 = Rectangle(width: 16.5, height: 14.0, cornerRadius: 0.0)
pageOverlay1.color = grey2
pageOverlay1.center.y = -15.5
pageOverlay1.center.x = -12.0

let printerHead = Rectangle(width: 2.0, height: 0.75, cornerRadius: 0.15)
printerHead.color = black1
printerHead.center.x = -16.75
printerHead.center.y = -5.95

let printerCover = Rectangle(width: 12.5, height: 0.75, cornerRadius: 0.0)
printerCover.color = black2
printerCover.center.x = -12.0
printerCover.center.y = -5.750

let printerTop = Rectangle(width: 16.0, height: 1.0, cornerRadius: 0.15)
printerTop.color = beige2
printerTop.center.x = -12.0
printerTop.center.y = -6.625

let printerBody = Rectangle(width: 17.0, height: 3.75, cornerRadius: 0.15)
printerBody.color = beige1
printerBody.center.x = -12.0
printerBody.center.y = -8.5

let groove1 = Rectangle(width: 1.25, height: 0.2, cornerRadius: 0.0)
groove1.color = beige4
groove1.center.x = -2.125
groove1.center.y = -5.875

let groove2 = Rectangle(width: 1.25, height: 0.2, cornerRadius: 0.0)
groove2.color = beige4
groove2.center.x = -2.125
groove2.center.y = -6.375

let groove3 = Rectangle(width: 1.25, height: 0.2, cornerRadius: 0.0)
groove3.color = beige4
groove3.center.x = -2.125
groove3.center.y = -6.875

let groove4 = Rectangle(width: 1.25, height: 0.2, cornerRadius: 0.0)
groove4.color = beige4
groove4.center.x = -2.125
groove4.center.y = -7.375

let groove5 = Rectangle(width: 1.25, height: 0.2, cornerRadius: 0.0)
groove5.color = beige4
groove5.center.x = -2.125
groove5.center.y = -7.875

let groove6 = Rectangle(width: 1.25, height: 0.2, cornerRadius: 0.0)
groove6.color = beige4
groove6.center.x = -2.125
groove6.center.y = -8.375

let printerButtonArea = Rectangle(width: 2.75, height: 1.25, cornerRadius: 0.30)
printerButtonArea.color = beige3
printerButtonArea.borderColor = beige4
printerButtonArea.borderWidth = 1.0
printerButtonArea.center.x = -18.625
printerButtonArea.center.y = -9.25

let printerButton = Rectangle(width: 1.25, height: 0.5, cornerRadius: 0.25)
printerButton.color = beige1
printerButton.center.x = -18.375
printerButton.center.y = -9.25

let printerLight = Circle(radius: 0.175)
printerLight.color = red1
printerLight.center.x = -19.5
printerLight.center.y = -9.25


func scale(scaleFactor: Double) {
    macBase.scale = scaleFactor
    macBody.scale = scaleFactor
    macScreen.scale = scaleFactor
    macGroove.scale = scaleFactor
    macDiskSlot.scale = scaleFactor
    macDiskHole.scale = scaleFactor
    macDisplay1.scale = scaleFactor
    hello.scale = scaleFactor
    printButton.scale = scaleFactor
    printButtonBorder.scale = scaleFactor
    printButtonText.fontSize = scaleFactor
    arrow.scale = scaleFactor
    macOverlay.scale = scaleFactor
    
    connectingCord.scale = scaleFactor
    
    printerBack.scale = scaleFactor
    printerCoverBack.scale = scaleFactor
    paper.scale = scaleFactor
    pageOverlay1.scale = scaleFactor
    printerHead.scale = scaleFactor
    printerCover.scale = scaleFactor
    printerTop.scale = scaleFactor
    printerBody.scale = scaleFactor
    groove1.scale = scaleFactor
    groove2.scale = scaleFactor
    groove3.scale = scaleFactor
    groove4.scale = scaleFactor
    groove5.scale = scaleFactor
    groove6.scale = scaleFactor
    printerButtonArea.scale = scaleFactor
    printerButton.scale = scaleFactor
    printerLight.scale = scaleFactor
}

func centerXShift(scaleFactor: Double, centerXShift: Double) {
    macBase.center.x = (13.0*scaleFactor) + centerXShift
    macBody.center.x = (13.0*scaleFactor) + centerXShift
    macScreen.center.x = (13.0*scaleFactor) + centerXShift
    macGroove.center.x = (13.0*scaleFactor) + centerXShift
    macDiskSlot.center.x = (16.0*scaleFactor) + centerXShift
    macDiskHole.center.x = (18.75*scaleFactor) + centerXShift
    macDisplay1.center.x = (13.0*scaleFactor) + centerXShift
    hello.center.x = (13.0*scaleFactor) + centerXShift
    printButton.center.x = (13.0*scaleFactor) + centerXShift
    printButtonBorder.center.x = (13.0*scaleFactor) + centerXShift
    printButtonText.center.x = (13.0*scaleFactor) + centerXShift
    screenText.center.x = (13.0*scaleFactor) + centerXShift
    tapPrompt.center.x = (24.0*scaleFactor) + centerXShift
    arrow.center.x = (24.0*scaleFactor) + centerXShift
    macOverlay.center.x = (13.0*scaleFactor) + centerXShift
    
    connectingCord.center.x = (0.0*scaleFactor) + centerXShift
    
    printerBack.center.x = (-11.25*scaleFactor) + centerXShift
    printerCoverBack.center.x = (-12.0*scaleFactor) + centerXShift
    paper.center.x  = (-12.0*scaleFactor) + centerXShift
    printedText1.center.x = (-12.0*scaleFactor) + centerXShift
    printedText2.center.x = (-12.0*scaleFactor) + centerXShift
    printedText3.center.x = (-12.0*scaleFactor) + centerXShift
    printedText4.center.x = (-12.0*scaleFactor) + centerXShift
    printedText5.center.x = (-12.0*scaleFactor) + centerXShift
    printedText6.center.x = (-12.0*scaleFactor) + centerXShift
    printedText7.center.x = (-12.0*scaleFactor) + centerXShift
    printedText8.center.x = (-12.0*scaleFactor) + centerXShift
    printedText9.center.x = (-12.0*scaleFactor) + centerXShift
    printedText10.center.x = (-12.0*scaleFactor) + centerXShift
    printedText11.center.x = (-12.0*scaleFactor) + centerXShift
    printedText12.center.x = (-12.0*scaleFactor) + centerXShift
    pageOverlay1.center.x = (-12.0*scaleFactor) + centerXShift
    printerHead.center.x = (-16.75*scaleFactor) + centerXShift
    printerCover.center.x = (-12.0*scaleFactor) + centerXShift
    printerTop.center.x = (-12.0*scaleFactor) + centerXShift
    printerBody.center.x = (-12.0*scaleFactor) + centerXShift
    groove1.center.x = (-2.125*scaleFactor) + centerXShift
    groove2.center.x = (-2.125*scaleFactor) + centerXShift
    groove3.center.x = (-2.125*scaleFactor) + centerXShift
    groove4.center.x = (-2.125*scaleFactor) + centerXShift
    groove5.center.x = (-2.125*scaleFactor) + centerXShift
    groove6.center.x = (-2.125*scaleFactor) + centerXShift
    printerButtonArea.center.x = (-18.625*scaleFactor) + centerXShift
    printerButton.center.x = (-18.375*scaleFactor) + centerXShift
    printerLight.center.x = (-19.5*scaleFactor) + centerXShift
}

func centerYShift(scaleFactor: Double, centerYShift: Double) {
    macBase.center.y = (-8.375*scaleFactor) + centerYShift
    macBody.center.y = (0.0*scaleFactor) + centerYShift
    macScreen.center.y = (2.0*scaleFactor) + centerYShift
    macGroove.center.y = (-5.5*scaleFactor) + centerYShift
    macDiskSlot.center.y = (-5.5*scaleFactor) + centerYShift
    macDiskHole.center.y = (-5.5*scaleFactor) + centerYShift
    macDisplay1.center.y = (2.0*scaleFactor) + centerYShift
    hello.center.y = (2.0*scaleFactor) + centerYShift
    printButton.center.y = (0.0*scaleFactor) + centerYShift
    printButtonBorder.center.y = (0.0*scaleFactor) + centerYShift
    printButtonText.center.y = (0.0*scaleFactor) + centerYShift
    screenText.center.y = (3.75*scaleFactor) + centerYShift
    tapPrompt.center.y = (3.75*scaleFactor) + centerYShift
    arrow.center.y = (0.0*scaleFactor) + centerYShift
    macOverlay.center.y = (0.0*scaleFactor) + centerYShift
    
    connectingCord.center.y = (-9.75*scaleFactor) + centerYShift
    
    printerBack.center.y = (-7.125*scaleFactor) + centerYShift
    printerCoverBack.center.y = (-5.75*scaleFactor) + centerYShift
    paper.center.y = (-13.0*scaleFactor) + centerYShift
    printedText1.center.y = (-6.75*scaleFactor) + centerYShift
    printedText2.center.y = (-7.25*scaleFactor) + centerYShift
    printedText3.center.y = (-7.75*scaleFactor) + centerYShift
    printedText4.center.y = (-8.25*scaleFactor) + centerYShift
    printedText5.center.y = (-8.75*scaleFactor) + centerYShift
    printedText6.center.y = (-9.25*scaleFactor) + centerYShift
    printedText7.center.y = (-9.75*scaleFactor) + centerYShift
    printedText8.center.y = (-10.25*scaleFactor) + centerYShift
    printedText9.center.y = (-10.75*scaleFactor) + centerYShift
    printedText10.center.y = (-11.25*scaleFactor) + centerYShift
    printedText11.center.y = (-11.75*scaleFactor) + centerYShift
    printedText12.center.y = (-19.0*scaleFactor) + centerYShift
    pageOverlay1.center.y = (-15.5*scaleFactor) + centerYShift
    printerHead.center.y = (-5.95*scaleFactor) + centerYShift
    printerCover.center.y = (-5.75*scaleFactor) + centerYShift
    printerTop.center.y = (-6.625*scaleFactor) + centerYShift
    printerBody.center.y = (-8.5*scaleFactor) + centerYShift
    groove1.center.y = (-5.875*scaleFactor) + centerYShift
    groove2.center.y = (-6.375*scaleFactor) + centerYShift
    groove3.center.y = (-6.875*scaleFactor) + centerYShift
    groove4.center.y = (-7.375*scaleFactor) + centerYShift
    groove5.center.y = (-7.875*scaleFactor) + centerYShift
    groove6.center.y = (-8.375*scaleFactor) + centerYShift
    printerButtonArea.center.y = (-9.25*scaleFactor) + centerYShift
    printerButton.center.y = (-9.25*scaleFactor) + centerYShift
    printerLight.center.y = (-9.25*scaleFactor) + centerYShift
}



var player: AVAudioPlayer?
func playSound() {
    guard let url = Bundle.main.url(forResource: "Printer2", withExtension: "mp3") else { return }
    
    do {
        try AVAudioSession.sharedInstance().setCategory(AVAudioSessionCategoryPlayback)
        try AVAudioSession.sharedInstance().setActive(true)
        
        player = try AVAudioPlayer(contentsOf: url, fileTypeHint: AVFileType.mp3.rawValue)
        
        guard let player = player else { return }
        
        player.play()
        
    } catch let error {
        print(error.localizedDescription)
    }
}






// Animations
animate(duration: 0.8, delay: 2.0, {
    macDisplay1.color = blue2
    printerLight.color = red1
})

animate(duration: 0.4, delay: 2.8, {
    hello.tint = black1
    printerLight.color = yellow1
})

animate(duration: 2.0, delay: 3.4, {
    scale(scaleFactor: 1.75)
    centerXShift(scaleFactor: 1.75, centerXShift: -22.75)
    centerYShift(scaleFactor: 1.75, centerYShift: 0.0)
    
    screenText.fontSize = 24.0
    tapPrompt.fontSize = 22.0
    printButtonText.fontSize = 24.0
    
})

animate(duration: 0.4, delay: 7.0, {hello.tint = .clear})

animate(duration: 0.4, delay: 7.4, {
    printButton.color = white1
    printButtonBorder.color = black1
    printButtonText.string = "PRINT"
    screenText.string = "Form ITR-1"
    tapPrompt.string = "Tap!"
    arrow.tint = grey1
    printedText1.string = "IT Dept. of India"
    printedText2.string = "Indian Individual Income Tax Return"
    printedText3.string = "ITR-1                        AY 2017-18"
    printedText4.string = ""
    printedText5.string = "Mr. Yash Rajeev Banka"
    printedText6.string = "Mumbai, Maharashtra, India"
    printedText7.string = "Age: 18 years"
    printedText8.string = "Sex: Male"
    printedText9.string = "Occupation: Student"
    printedText10.string = ""
    printedText11.string = "Date of Filing: April 1, 2018"
    printedText12.string = "To , From Yash :)"
})

var bool1 = false
var bool2 = false
DispatchQueue.main.asyncAfter(deadline: .now() + 7.2) {
    bool1 = true
}

macOverlay.onTouchUp {
    if (bool1 == true) {
        animate(duration: 2.0, delay: 0.0, {
            centerXShift(scaleFactor: 1.75, centerXShift: 20.0)
            printButton.color = grey1
            printButtonText.string = "..."
        })
        bool1 = false
        
        DispatchQueue.main.asyncAfter(deadline: .now() + 2.0) {
            animate(duration: 0.2, delay: 0.0, {
                printerLight.color = green1
            })
            for i in 0...4 {
                playSound()
                let iDouble = Double(i)
                animate(duration: 1.2, delay: (2.4*iDouble) , {
                    printerHead.center.x += 16.5
                })
                animate(duration: 1.2, delay: (1.2 + 2.4*iDouble), {
                    printerHead.center.x -= 16.5
                    paper.center.y += 2.875
                    printedText1.center.y += 2.875
                    printedText2.center.y += 2.875
                    printedText3.center.y += 2.875
                    printedText4.center.y += 2.875
                    printedText5.center.y += 2.875
                    printedText6.center.y += 2.875
                    printedText7.center.y += 2.875
                    printedText8.center.y += 2.875
                    printedText9.center.y += 2.875
                    printedText10.center.y += 2.875
                    printedText11.center.y += 2.875
                    printedText12.center.y += 2.875
                })
            }
            animate(duration: 1.2, delay: 10.8, {
                paper.center.y += 14.0
                printedText1.center.y += 14.0
                printedText2.center.y += 14.0
                printedText3.center.y += 14.0
                printedText4.center.y += 14.0
                printedText5.center.y += 14.0
                printedText6.center.y += 14.0
                printedText7.center.y += 14.0
                printedText8.center.y += 14.0
                printedText9.center.y += 14.0
                printedText10.center.y += 14.0
                printedText11.center.y += 14.0
                printedText12.center.y += 14.0
            })
        }

    }
}




//#-end-hidden-code
/*:
 **Run the code to enjoy the Introduction before moving on to the next page.**
 
 **About:** India has a complicated income tax structure with numerous tax slabs and a multitude of deductions, exemptions, surcharges and cesses. To add to this, rules change with each annual budget.
 In this chapter, I attempt to establish a workflow to help a person estimate his tax liability.
 */
